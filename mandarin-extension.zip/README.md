# 听懂 — Bilibili Mandarin Listening Room

A Chrome Manifest V3 extension for the exact original recording:
https://www.bilibili.com/video/BV1MRJa6sEsk/

The extension runs on the original Bilibili page and reads its actual HTML video clock. Bilibili streams the original recording; the extension does not rehost audio. Works in desktop Chrome and Chromium. Chrome on iPhone does not support this extension.

## Install

1. Extract the extension ZIP to a permanent folder.
2. Open `chrome://extensions` in desktop Chrome.
3. Enable **Developer mode**, choose **Load unpacked**, and select the extracted folder containing `manifest.json`.
4. Open the exact recording above and press **听懂 · Learn** in the lower right. Start the original Bilibili player if required.

This is an unpacked extension, not a Chrome Web Store installation. Leave the extracted folder in place. To remove it, choose Remove on `chrome://extensions`.

## Controls

- Play/pause, ±10 seconds, position slider, and 0.5×–2× playback speed.
- Chinese, natural English, and tone-marked pinyin appear together when lesson data is present.
- Click a Chinese or pinyin word for its explanation and word replay.
- Replay a sentence from its transcript timestamp or the caption replay button. Playback stops at the aligned sentence end.
- Follow the active sentence automatically, or disable Follow to browse the transcript. Search all three lines.
- Edit `data/lesson.json`, then reload the extension and original video tab, or import edited JSON in the panel. Imports remain in the current tab. Export saves an editable copy.

## Data and privacy

Only this exact video's desktop/mobile URL is matched. No cookies, browsing history, account credentials, or microphone permissions are requested. No audio or imported JSON is uploaded. Bilibili's normal network activity and account restrictions still apply. Navigating to a different Bilibili video hides the panel and stops extension replay control. A page reload on the exact URL activates it again.

`data/lesson.json` records transcription, alignment, and review status. An empty sentences array means transcript preparation is pending; the extension does not invent subtitles. Model timestamps and unreviewed transcripts must not be mistaken for corrected forced alignment.

The extension reads Bilibili's HTML video element. Bilibili may change its page, override playback rate, or restrict playback by region/account. It does not bypass access restrictions or advertisements. Sentence stopping uses the browser animation clock and may be delayed in a background tab; study with the tab visible.

## Bundled lesson status

The complete recording was transcribed with Whisper-1 in 37 chunks. The lesson contains 460 subtitle segments and 5,714 vocabulary units, with automated Chinese correction, English translation, and contextual tone-marked pinyin. Stable-ts / Whisper tiny performed forced alignment within ASR-derived sentence ranges. 97 zero-length forced word results use ASR timing as a fallback, identified by `timingStatus: "asr-fallback"`. Common names and idioms received an additional manual correction pass. The transcript remains an automated draft; no complete human linguistic or acoustic review is claimed.
