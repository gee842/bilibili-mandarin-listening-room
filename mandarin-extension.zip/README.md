# 听懂 — Bilibili Mandarin Listening Room 0.2

A desktop Chrome extension that connects to Bilibili’s original video player. Audio streams from Bilibili; nothing is rehosted. The bundled full lesson is for [《战国策》：看透人心，守住自己 — 故纸观今](https://www.bilibili.com/video/BV1MRJa6sEsk/).

## Install or update

1. Extract the extension ZIP to a permanent folder.
2. In desktop Chrome, open `chrome://extensions`, enable **Developer mode**, then choose **Load unpacked** and select the folder containing `manifest.json`.
3. When updating an existing unpacked installation, replace its files, press **Reload** on the extension card, then refresh the Bilibili tab.
4. Open a Bilibili video. The lesson panel appears below the player. The extension toolbar button shows or hides it.

Chrome on iPhone does not support Chrome extensions. The companion website remains available for mobile browsing.

## Study controls

- Chinese with compact tone-marked pinyin directly above the characters, plus natural English underneath. Word groups remain clickable and highlight together.
- Click a word to see its whole meaning, the individual character senses, and available composition/idiom notes. Literal senses are a reading aid; they are not an etymology. Personal names are identified as names.
- Sentence/word replay, play/pause, ±10 seconds, position slider and speed 0.5×–2×.
- The panel sits below the player in normal/wide viewing. In browser fullscreen, it moves inside the video’s fullscreen container as an overlay. Use the panel’s **Fullscreen** button for this study view. Native system video fullscreen and picture-in-picture cannot display arbitrary HTML overlays.
- **Transcript & lessons** opens the following transcript, search and lesson file controls. These remain available in fullscreen.

## Other videos

Playback controls work on other Bilibili BV video pages. Each video and multipart episode has a separate lesson identity. Captions from the bundled recording are never reused on another recording.

For another video, open **Transcript & lessons**, export a blank template, then import a matching aligned lesson JSON. Imports are validated and saved in Chrome’s local extension storage, so the lesson loads again on return. This extension does not automatically transcribe or translate other videos and does not contact a speech/translation service. You must supply the Chinese, English, pinyin and word timings. A new video without a lesson shows a clear empty state while playback controls remain usable.

The schema is version 1. `source.bvid` must match the current video and `source.page` the current `?p=` part (default 1). Each sentence needs `start`, `end`, `zh`, `en`, `pinyin`, `words`; each word needs the same timing/text fields. Times are absolute seconds within the recording. Words must concatenate to sentence Chinese, ignoring punctuation and whitespace. Optional `characterBreakdowns` maps a word’s Chinese text to `{characters:[{zh,pinyin,en}],note}`. The character list must reproduce the word exactly. Export includes all editable data. Imports must be under 5 MB; Chrome’s local storage quota also applies.

## Dictionary attribution

Character gloss data is adapted from [CC-CEDICT](https://cc-cedict.org/wiki/), downloaded from MDBG, under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Dictionary senses were abridged, some learner glosses added, readings selected automatically, and composition notes added. The derived character glosses and notes in `data/lesson.json` are shared under CC BY-SA 4.0. The dictionary attribution is also visible in word explanations. These data additions do not change the recording’s rights.

## Data and limitations

The extension runs only on the desktop/mobile Bilibili domains and uses local extension storage for lesson files. It does not request cookie, history, microphone or account permissions. It does not upload audio, imported JSON or browsing activity. It does not bypass Bilibili access restrictions. Automatic video changes discard the prior lesson and any scheduled replay stop before loading the matching lesson.

The bundled recording has 460 subtitle segments, 5,714 aligned vocabulary occurrences and 2,347 distinct multi-character breakdowns. Whisper-1 supplied transcription, automated editing supplied English/pinyin and Chinese correction, and stable-ts / Whisper tiny supplied forced alignment. 97 zero-length forced results retain ASR timing (`timingStatus: "asr-fallback"`). The transcript, readings and dictionary-sense selection remain an automated draft, without complete human acoustic or linguistic review. Some highlight groups are phrases or imperfect word boundaries.

Bilibili may change its layout or override playback settings. Replay stopping uses the browser animation clock and may be delayed in background tabs. Native video-only fullscreen/PiP and iPhone extension support are outside the browser’s available overlay capabilities.
